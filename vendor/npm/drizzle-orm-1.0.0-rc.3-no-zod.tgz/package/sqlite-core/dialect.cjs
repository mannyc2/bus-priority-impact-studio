Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
const require_runtime = require('../_virtual/_rolldown/runtime.cjs');
const require_sqlite_core_view_base = require('./view-base.cjs');
let __entity_ts = require("../entity.cjs");
let __subquery_ts = require("../subquery.cjs");
let __view_common_ts = require("../view-common.cjs");
let __table_ts = require("../table.cjs");
let __column_ts = require("../column.cjs");
let __utils_ts = require("../utils.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let ___relations_ts = require("../_relations.cjs");
___relations_ts = require_runtime.__toESM(___relations_ts);
let __relations_ts = require("../relations.cjs");
let __migrator_utils_ts = require("../migrator.utils.cjs");
let __sql_index_ts = require("../sql/index.cjs");
let __up_migrations_sqlite_ts = require("../up-migrations/sqlite.cjs");
let __errors_ts = require("../errors.cjs");
let __alias_ts = require("../alias.cjs");
let __sqlite_core_columns_index_ts = require("./columns/index.cjs");
let __sqlite_core_table_ts = require("./table.cjs");

//#region src/sqlite-core/dialect.ts
var SQLiteDialect = class {
	static [__entity_ts.entityKind] = "SQLiteDialect";
	constructor(_config) {}
	escapeName(name) {
		return `"${name.replace(/"/g, "\"\"")}"`;
	}
	escapeParam(_num) {
		return "?";
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const withSqlChunks = [__sql_sql_ts.sql`with `];
		for (const [i, w] of queries.entries()) {
			withSqlChunks.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql})`);
			if (i < queries.length - 1) withSqlChunks.push(__sql_sql_ts.sql`, `);
		}
		withSqlChunks.push(__sql_sql_ts.sql` `);
		return __sql_sql_ts.sql.join(withSqlChunks);
	}
	buildDeleteQuery({ table, where, returning, withList, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		return __sql_sql_ts.sql`${withSql}delete from ${table}${where ? __sql_sql_ts.sql` where ${where}` : void 0}${returningSql}${this.buildOrderBy(orderBy)}${this.buildLimit(limit)}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[__table_ts.Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setLength = columnNames.length;
		return __sql_sql_ts.sql.join(columnNames.flatMap((colName, i) => {
			const col = tableColumns[colName];
			const onUpdateFnResult = col.onUpdateFn?.();
			const value = set[colName] ?? ((0, __entity_ts.is)(onUpdateFnResult, __sql_sql_ts.SQL) ? onUpdateFnResult : __sql_sql_ts.sql.param(onUpdateFnResult, col));
			const res = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}`;
			if (i < setLength - 1) return [res, __sql_sql_ts.sql.raw(", ")];
			return [res];
		}));
	}
	buildUpdateQuery({ table, set, where, returning, withList, joins, from, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const setSql = this.buildUpdateSet(table, set);
		const fromSql = from && __sql_sql_ts.sql.join([__sql_sql_ts.sql.raw(" from "), this.buildFromTable(from)]);
		const joinsSql = this.buildJoins(joins);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		return __sql_sql_ts.sql`${withSql}update ${table} set ${setSql}${fromSql}${joinsSql}${where ? __sql_sql_ts.sql` where ${where}` : void 0}${returningSql}${this.buildOrderBy(orderBy)}${this.buildLimit(limit)}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false } = {}) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) && field.isSelectionField) {
				if (!isSingleTable && field.origin !== void 0) chunk.push(__sql_sql_ts.sql.identifier(field.origin), __sql_sql_ts.sql.raw("."));
				chunk.push(__sql_sql_ts.sql.identifier(field.fieldAlias));
			} else if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) || (0, __entity_ts.is)(field, __sql_sql_ts.SQL)) {
				const query = (0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) ? field.sql : field;
				if (isSingleTable) {
					const newSql = new __sql_sql_ts.SQL(query.queryChunks.map((c) => {
						if ((0, __entity_ts.is)(c, __column_ts.Column)) return __sql_sql_ts.sql.identifier(c.name);
						return c;
					}));
					chunk.push(query.shouldInlineParams ? newSql.inlineParams() : newSql);
				} else chunk.push(query);
				if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased)) chunk.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
			} else if ((0, __entity_ts.is)(field, __column_ts.Column)) if (field.columnType === "SQLiteNumericBigInt") if (isSingleTable) chunk.push(field.isAlias ? __sql_sql_ts.sql`cast(${__sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name)} as text) as ${field}` : __sql_sql_ts.sql`cast(${__sql_sql_ts.sql.identifier(field.name)} as text)`);
			else chunk.push(field.isAlias ? __sql_sql_ts.sql`cast(${(0, __alias_ts.getOriginalColumnFromAlias)(field)} as text) as ${field}` : __sql_sql_ts.sql`cast(${field} as text)`);
			else if (isSingleTable) chunk.push(field.isAlias ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name)} as ${field}` : __sql_sql_ts.sql.identifier(field.name));
			else chunk.push(field.isAlias ? __sql_sql_ts.sql`${(0, __alias_ts.getOriginalColumnFromAlias)(field)} as ${field}` : field);
			else if ((0, __entity_ts.is)(field, __subquery_ts.Subquery)) {
				const entries = Object.entries(field._.selectedFields);
				if (entries.length === 1) {
					const entry = entries[0][1];
					const fieldDecoder = (0, __entity_ts.is)(entry, __sql_sql_ts.SQL) ? entry.decoder : (0, __entity_ts.is)(entry, __column_ts.Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
					if (fieldDecoder) field._.sql.decoder = fieldDecoder;
				}
				chunk.push(field);
			}
			if (i < columnsLen - 1) chunk.push(__sql_sql_ts.sql`, `);
			return chunk;
		});
		return __sql_sql_ts.sql.join(chunks);
	}
	buildJoins(joins) {
		if (!joins || joins.length === 0) return;
		const joinsArray = [];
		if (joins) for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(__sql_sql_ts.sql` `);
			const table = joinMeta.table;
			const onSql = joinMeta.on ? __sql_sql_ts.sql` on ${joinMeta.on}` : void 0;
			if ((0, __entity_ts.is)(table, __sqlite_core_table_ts.SQLiteTable)) {
				const tableName = table[__sqlite_core_table_ts.SQLiteTable.Symbol.Name];
				const tableSchema = table[__sqlite_core_table_ts.SQLiteTable.Symbol.Schema];
				const origTableName = table[__sqlite_core_table_ts.SQLiteTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join ${tableSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(tableSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origTableName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}${onSql}`);
			} else joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(__sql_sql_ts.sql` `);
		}
		return __sql_sql_ts.sql.join(joinsArray);
	}
	buildLimit(limit) {
		return typeof limit === "object" || typeof limit === "number" && limit >= 0 ? __sql_sql_ts.sql` limit ${limit}` : void 0;
	}
	buildOrderBy(orderBy) {
		const orderByList = [];
		if (orderBy) for (const [index, orderByValue] of orderBy.entries()) {
			orderByList.push(orderByValue);
			if (index < orderBy.length - 1) orderByList.push(__sql_sql_ts.sql`, `);
		}
		return orderByList.length > 0 ? __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByList)}` : void 0;
	}
	buildFromTable(table) {
		if ((0, __entity_ts.is)(table, __table_ts.Table) && table[__table_ts.Table.Symbol.IsAlias]) return __sql_sql_ts.sql`${__sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Schema] ?? "")}.`.if(table[__table_ts.Table.Symbol.Schema])}${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.OriginalName])} ${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Name])}`;
		if ((0, __entity_ts.is)(table, __sql_sql_ts.View) && table[__view_common_ts.ViewBaseConfig].isAlias) {
			let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].originalName)}`;
			if (table[__view_common_ts.ViewBaseConfig].schema) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].schema)}.${fullName}`;
			return __sql_sql_ts.sql`${fullName} ${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].name)}`;
		}
		return table;
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, limit, offset, distinct, setOperators }) {
		const fieldsList = fieldsFlat ?? (0, __utils_ts.orderSelectedFields)(fields);
		for (const f of fieldsList) if ((0, __entity_ts.is)(f.field, __column_ts.Column) && (0, __table_ts.getTableName)(f.field.table) !== ((0, __entity_ts.is)(table, __subquery_ts.Subquery) ? table._.alias : (0, __entity_ts.is)(table, require_sqlite_core_view_base.SQLiteViewBase) ? table[__view_common_ts.ViewBaseConfig].name : (0, __entity_ts.is)(table, __sql_sql_ts.SQL) ? void 0 : (0, __table_ts.getTableName)(table)) && !((table) => joins?.some(({ alias }) => alias === (table[__table_ts.Table.Symbol.IsAlias] ? (0, __table_ts.getTableName)(table) : table[__table_ts.Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = (0, __table_ts.getTableName)(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		const distinctSql = distinct ? __sql_sql_ts.sql` distinct` : void 0;
		const selection = this.buildSelection(fieldsList, { isSingleTable });
		const tableSql = this.buildFromTable(table);
		const joinsSql = this.buildJoins(joins);
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const havingSql = having ? __sql_sql_ts.sql` having ${having}` : void 0;
		const groupByList = [];
		if (groupBy) for (const [index, groupByValue] of groupBy.entries()) {
			groupByList.push(groupByValue);
			if (index < groupBy.length - 1) groupByList.push(__sql_sql_ts.sql`, `);
		}
		const finalQuery = __sql_sql_ts.sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupByList.length > 0 ? __sql_sql_ts.sql` group by ${__sql_sql_ts.sql.join(groupByList)}` : void 0}${havingSql}${this.buildOrderBy(orderBy)}${this.buildLimit(limit)}${offset ? __sql_sql_ts.sql` offset ${offset}` : void 0}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		const [setOperator, ...rest] = setOperators;
		if (!setOperator) throw new Error("Cannot pass undefined values to any set operator");
		if (rest.length === 0) return this.buildSetOperationQuery({
			leftSelect,
			setOperator
		});
		return this.buildSetOperations(this.buildSetOperationQuery({
			leftSelect,
			setOperator
		}), rest);
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, limit, orderBy, offset } }) {
		const leftChunk = __sql_sql_ts.sql`${leftSelect.getSQL()} `;
		const rightChunk = __sql_sql_ts.sql`${rightSelect.getSQL()}`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const singleOrderBy of orderBy) if ((0, __entity_ts.is)(singleOrderBy, __sqlite_core_columns_index_ts.SQLiteColumn)) orderByValues.push(__sql_sql_ts.sql.identifier(singleOrderBy.name));
			else if ((0, __entity_ts.is)(singleOrderBy, __sql_sql_ts.SQL)) {
				for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
					const chunk = singleOrderBy.queryChunks[i];
					if ((0, __entity_ts.is)(chunk, __sqlite_core_columns_index_ts.SQLiteColumn)) singleOrderBy.queryChunks[i] = __sql_sql_ts.sql.identifier(chunk.name);
				}
				orderByValues.push(__sql_sql_ts.sql`${singleOrderBy}`);
			} else orderByValues.push(__sql_sql_ts.sql`${singleOrderBy}`);
			orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByValues, __sql_sql_ts.sql`, `)}`;
		}
		const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? __sql_sql_ts.sql` limit ${limit}` : void 0;
		const operatorChunk = __sql_sql_ts.sql.raw(`${type} ${isAll ? "all " : ""}`);
		const offsetSql = offset ? __sql_sql_ts.sql` offset ${offset}` : void 0;
		return __sql_sql_ts.sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select }) {
		const valuesSqlList = [];
		const columns = table[__table_ts.Table.Symbol.Columns];
		const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrder = colEntries.map(([, column]) => __sql_sql_ts.sql.identifier(column.name));
		if (select) {
			const select = valuesOrSelect;
			if ((0, __entity_ts.is)(select, __sql_sql_ts.SQL)) valuesSqlList.push(select);
			else valuesSqlList.push(select.getSQL());
		} else {
			const values = valuesOrSelect;
			valuesSqlList.push(__sql_sql_ts.sql.raw("values "));
			for (const [valueIndex, value] of values.entries()) {
				const valueList = [];
				for (const [fieldName, col] of colEntries) {
					const colValue = value[fieldName];
					if (colValue === void 0 || (0, __entity_ts.is)(colValue, __sql_sql_ts.Param) && colValue.value === void 0) {
						let defaultValue;
						if (col.default !== null && col.default !== void 0) defaultValue = (0, __entity_ts.is)(col.default, __sql_sql_ts.SQL) ? col.default : __sql_sql_ts.sql.param(col.default, col);
						else if (col.defaultFn !== void 0) {
							const defaultFnResult = col.defaultFn();
							defaultValue = (0, __entity_ts.is)(defaultFnResult, __sql_sql_ts.SQL) ? defaultFnResult : __sql_sql_ts.sql.param(defaultFnResult, col);
						} else if (!col.default && col.onUpdateFn !== void 0) {
							const onUpdateFnResult = col.onUpdateFn();
							defaultValue = (0, __entity_ts.is)(onUpdateFnResult, __sql_sql_ts.SQL) ? onUpdateFnResult : __sql_sql_ts.sql.param(onUpdateFnResult, col);
						} else defaultValue = __sql_sql_ts.sql`null`;
						valueList.push(defaultValue);
					} else valueList.push(colValue);
				}
				valuesSqlList.push(valueList);
				if (valueIndex < values.length - 1) valuesSqlList.push(__sql_sql_ts.sql`, `);
			}
		}
		const withSql = this.buildWithCTE(withList);
		const valuesSql = __sql_sql_ts.sql.join(valuesSqlList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		return __sql_sql_ts.sql`${withSql}insert into ${table} ${insertOrder} ${valuesSql}${onConflict?.length ? __sql_sql_ts.sql.join(onConflict) : void 0}${returningSql}`;
	}
	sqlToQuery(sql, invokeSource) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			invokeSource
		});
	}
	/** @deprecated */
	_buildRelationalQuery({ fullSchema, schema, tableNamesMap, table, tableConfig, queryConfig: config, tableAlias, nestedQueryRelation, joinOn }) {
		let selection = [];
		let limit, offset, orderBy = [], where;
		const joins = [];
		if (config === true) selection = Object.entries(tableConfig.columns).map(([key, value]) => ({
			dbKey: value.name,
			tsKey: key,
			field: (0, __alias_ts.aliasedTableColumn)(value, tableAlias),
			relationTableTsKey: void 0,
			isJson: false,
			selection: []
		}));
		else {
			const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [key, (0, __alias_ts.aliasedTableColumn)(value, tableAlias)]));
			if (config.where) {
				const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, ___relations_ts.getOperators()) : config.where;
				where = whereSql && (0, __alias_ts.mapColumnsInSQLToAlias)(whereSql, tableAlias);
			}
			const fieldsSelection = [];
			let selectedColumns = [];
			if (config.columns) {
				let isIncludeMode = false;
				for (const [field, value] of Object.entries(config.columns)) {
					if (value === void 0) continue;
					if (field in tableConfig.columns) {
						if (!isIncludeMode && value === true) isIncludeMode = true;
						selectedColumns.push(field);
					}
				}
				if (selectedColumns.length > 0) selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
			} else selectedColumns = Object.keys(tableConfig.columns);
			for (const field of selectedColumns) {
				const column = tableConfig.columns[field];
				fieldsSelection.push({
					tsKey: field,
					value: column
				});
			}
			let selectedRelations = [];
			if (config.with) selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({
				tsKey,
				queryConfig,
				relation: tableConfig.relations[tsKey]
			}));
			let extras;
			if (config.extras) {
				extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql: __sql_sql_ts.sql }) : config.extras;
				for (const [tsKey, value] of Object.entries(extras)) fieldsSelection.push({
					tsKey,
					value: (0, __alias_ts.mapColumnsInAliasedSQLToAlias)(value, tableAlias)
				});
			}
			for (const { tsKey, value } of fieldsSelection) selection.push({
				dbKey: (0, __entity_ts.is)(value, __sql_sql_ts.SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
				tsKey,
				field: (0, __entity_ts.is)(value, __column_ts.Column) ? (0, __alias_ts.aliasedTableColumn)(value, tableAlias) : value,
				relationTableTsKey: void 0,
				isJson: false,
				selection: []
			});
			let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, ___relations_ts.getOrderByOperators()) : config.orderBy ?? [];
			if (!Array.isArray(orderByOrig)) orderByOrig = [orderByOrig];
			orderBy = orderByOrig.map((orderByValue) => {
				if ((0, __entity_ts.is)(orderByValue, __column_ts.Column)) return (0, __alias_ts.aliasedTableColumn)(orderByValue, tableAlias);
				return (0, __alias_ts.mapColumnsInSQLToAlias)(orderByValue, tableAlias);
			});
			limit = config.limit;
			offset = config.offset;
			for (const { tsKey: selectedRelationTsKey, queryConfig: selectedRelationConfigValue, relation } of selectedRelations) {
				const normalizedRelation = ___relations_ts.normalizeRelation(schema, tableNamesMap, relation);
				const relationTableTsName = tableNamesMap[(0, __table_ts.getTableUniqueName)(relation.referencedTable)];
				const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
				const joinOn = (0, __sql_index_ts.and)(...normalizedRelation.fields.map((field, i) => (0, __sql_index_ts.eq)((0, __alias_ts.aliasedTableColumn)(normalizedRelation.references[i], relationTableAlias), (0, __alias_ts.aliasedTableColumn)(field, tableAlias))));
				const builtRelation = this._buildRelationalQuery({
					fullSchema,
					schema,
					tableNamesMap,
					table: fullSchema[relationTableTsName],
					tableConfig: schema[relationTableTsName],
					queryConfig: (0, __entity_ts.is)(relation, ___relations_ts.One) ? selectedRelationConfigValue === true ? { limit: 1 } : {
						...selectedRelationConfigValue,
						limit: 1
					} : selectedRelationConfigValue,
					tableAlias: relationTableAlias,
					joinOn,
					nestedQueryRelation: relation
				});
				const field = __sql_sql_ts.sql`(${builtRelation.sql})`.as(selectedRelationTsKey);
				selection.push({
					dbKey: selectedRelationTsKey,
					tsKey: selectedRelationTsKey,
					field,
					relationTableTsKey: relationTableTsName,
					isJson: true,
					selection: builtRelation.selection
				});
			}
		}
		if (selection.length === 0) throw new __errors_ts.DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.` });
		let result;
		where = (0, __sql_index_ts.and)(joinOn, where);
		if (nestedQueryRelation) {
			let field = __sql_sql_ts.sql`json_array(${__sql_sql_ts.sql.join(selection.map(({ field }) => (0, __entity_ts.is)(field, __sqlite_core_columns_index_ts.SQLiteColumn) ? __sql_sql_ts.sql.identifier(field.name) : (0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) ? field.sql : field), __sql_sql_ts.sql`, `)})`;
			if ((0, __entity_ts.is)(nestedQueryRelation, ___relations_ts.Many)) field = __sql_sql_ts.sql`coalesce(json_group_array(${field}), json_array())`;
			const nestedSelection = [{
				dbKey: "data",
				tsKey: "data",
				field: field.as("data"),
				isJson: true,
				relationTableTsKey: tableConfig.tsName,
				selection
			}];
			if (limit !== void 0 || offset !== void 0 || orderBy.length > 0) {
				result = this.buildSelectQuery({
					table: (0, __alias_ts.aliasedTable)(table, tableAlias),
					fields: {},
					fieldsFlat: [{
						path: [],
						field: __sql_sql_ts.sql.raw("*")
					}],
					where,
					limit,
					offset,
					orderBy,
					setOperators: []
				});
				where = void 0;
				limit = void 0;
				offset = void 0;
				orderBy = void 0;
			} else result = (0, __alias_ts.aliasedTable)(table, tableAlias);
			result = this.buildSelectQuery({
				table: (0, __entity_ts.is)(result, __sqlite_core_table_ts.SQLiteTable) ? result : new __subquery_ts.Subquery(result, {}, tableAlias),
				fields: {},
				fieldsFlat: nestedSelection.map(({ field }) => ({
					path: [],
					field: (0, __entity_ts.is)(field, __column_ts.Column) ? (0, __alias_ts.aliasedTableColumn)(field, tableAlias) : field
				})),
				joins,
				where,
				limit,
				offset,
				orderBy,
				setOperators: []
			});
		} else result = this.buildSelectQuery({
			table: (0, __alias_ts.aliasedTable)(table, tableAlias),
			fields: {},
			fieldsFlat: selection.map(({ field }) => ({
				path: [],
				field: (0, __entity_ts.is)(field, __column_ts.Column) ? (0, __alias_ts.aliasedTableColumn)(field, tableAlias) : field
			})),
			joins,
			where,
			limit,
			offset,
			orderBy,
			setOperators: []
		});
		return {
			tableTsKey: tableConfig.tsName,
			sql: result,
			selection
		};
	}
	nestedSelectionerror() {
		throw new __errors_ts.DrizzleError({ message: `Views with nested selections are not supported by the relational query builder` });
	}
	buildRqbColumn(table, column, key) {
		if ((0, __entity_ts.is)(column, __column_ts.Column)) {
			const name = __sql_sql_ts.sql`${table}.${__sql_sql_ts.sql.identifier(column.name)}`;
			switch (column.columnType) {
				case "SQLiteBigInt":
				case "SQLiteBlobJson":
				case "SQLiteBlobBuffer": return __sql_sql_ts.sql`hex(${name}) as ${__sql_sql_ts.sql.identifier(key)}`;
				case "SQLiteNumeric":
				case "SQLiteNumericNumber":
				case "SQLiteNumericBigInt": return __sql_sql_ts.sql`cast(${name} as text) as ${__sql_sql_ts.sql.identifier(key)}`;
				case "SQLiteCustomColumn": return __sql_sql_ts.sql`${column.jsonSelectIdentifier(name, __sql_sql_ts.sql)} as ${__sql_sql_ts.sql.identifier(key)}`;
				default: return __sql_sql_ts.sql`${name} as ${__sql_sql_ts.sql.identifier(key)}`;
			}
		}
		return __sql_sql_ts.sql`${table}.${(0, __entity_ts.is)(column, __sql_sql_ts.SQL.Aliased) ? __sql_sql_ts.sql.identifier(column.fieldAlias) : (0, __sql_index_ts.isSQLWrapper)(column) ? __sql_sql_ts.sql.identifier(key) : this.nestedSelectionerror()} as ${__sql_sql_ts.sql.identifier(key)}`;
	}
	unwrapAllColumns = (table, selection) => {
		return __sql_sql_ts.sql.join(Object.entries(table[__table_ts.TableColumns]).map(([k, v]) => {
			selection.push({
				key: k,
				field: v
			});
			return this.buildRqbColumn(table, v, k);
		}), __sql_sql_ts.sql`, `);
	};
	getSelectedTableColumns = (table, columns) => {
		const selectedColumns = [];
		const columnContainer = table[__table_ts.TableColumns];
		const entries = Object.entries(columns);
		let colSelectionMode;
		for (const [k, v] of entries) {
			if (v === void 0) continue;
			colSelectionMode = colSelectionMode || v;
			if (v) {
				const column = columnContainer[k];
				selectedColumns.push({
					column,
					tsName: k
				});
			}
		}
		if (colSelectionMode === false) for (const [k, v] of Object.entries(columnContainer)) {
			if (columns[k] === false) continue;
			selectedColumns.push({
				column: v,
				tsName: k
			});
		}
		return selectedColumns;
	};
	buildColumns = (table, selection, params) => params?.columns ? (() => {
		const columnIdentifiers = [];
		const selectedColumns = this.getSelectedTableColumns(table, params?.columns);
		for (const { column, tsName } of selectedColumns) {
			columnIdentifiers.push(this.buildRqbColumn(table, column, tsName));
			selection.push({
				key: tsName,
				field: column
			});
		}
		return columnIdentifiers.length ? __sql_sql_ts.sql.join(columnIdentifiers, __sql_sql_ts.sql`, `) : void 0;
	})() : this.unwrapAllColumns(table, selection);
	buildRelationalQuery({ schema, table, tableConfig, queryConfig: config, relationWhere, mode, isNested, errorPath, depth, throughJoin, jsonb }) {
		const selection = [];
		const isSingle = mode === "first";
		const params = config === true ? void 0 : config;
		const currentPath = errorPath ?? "";
		const currentDepth = depth ?? 0;
		if (!currentDepth) table = (0, __alias_ts.aliasedTable)(table, `d${currentDepth}`);
		const limit = isSingle ? 1 : params?.limit;
		const offset = params?.offset;
		const columns = this.buildColumns(table, selection, params);
		const where = params?.where && relationWhere ? (0, __sql_index_ts.and)((0, __relations_ts.relationsFilterToSQL)(table, params.where, tableConfig.relations, schema), relationWhere) : params?.where ? (0, __relations_ts.relationsFilterToSQL)(table, params.where, tableConfig.relations, schema) : relationWhere;
		const order = params?.orderBy ? (0, __relations_ts.relationsOrderToSQL)(table, params.orderBy) : void 0;
		const extras = params?.extras ? (0, __relations_ts.relationExtrasToSQL)(table, params.extras) : void 0;
		if (extras) selection.push(...extras.selection);
		const joins = params ? (() => {
			const { with: joins } = params;
			if (!joins) return;
			const withEntries = Object.entries(joins).filter(([_, v]) => v);
			if (!withEntries.length) return;
			return __sql_sql_ts.sql.join(withEntries.map(([k, join]) => {
				const relation = tableConfig.relations[k];
				const isSingle = (0, __entity_ts.is)(relation, __relations_ts.One);
				const targetTable = (0, __alias_ts.aliasedTable)(relation.targetTable, `d${currentDepth + 1}`);
				const throughTable = relation.throughTable ? (0, __alias_ts.aliasedTable)(relation.throughTable, `tr${currentDepth}`) : void 0;
				const { filter, joinCondition } = (0, __relations_ts.relationToSQL)(relation, table, targetTable, throughTable);
				const throughJoin = throughTable ? __sql_sql_ts.sql` inner join ${(0, __relations_ts.getTableAsAliasSQL)(throughTable)} on ${joinCondition}` : void 0;
				const innerQuery = this.buildRelationalQuery({
					table: targetTable,
					mode: isSingle ? "first" : "many",
					schema,
					queryConfig: join,
					tableConfig: schema[relation.targetTableName],
					relationWhere: filter,
					isNested: true,
					errorPath: `${currentPath.length ? `${currentPath}.` : ""}${k}`,
					depth: currentDepth + 1,
					throughJoin,
					jsonb
				});
				selection.push({
					field: targetTable,
					key: k,
					selection: innerQuery.selection,
					isArray: !isSingle,
					isOptional: (relation.optional ?? false) || join !== true && !!join.where
				});
				const jsonColumns = __sql_sql_ts.sql.join(innerQuery.selection.map((s) => {
					return __sql_sql_ts.sql`${__sql_sql_ts.sql.raw(this.escapeString(s.key))}, ${s.selection ? __sql_sql_ts.sql`${jsonb}(${__sql_sql_ts.sql.identifier(s.key)})` : __sql_sql_ts.sql.identifier(s.key)}`;
				}), __sql_sql_ts.sql`, `);
				const json = isNested ? jsonb : __sql_sql_ts.sql`json`;
				return isSingle ? __sql_sql_ts.sql`(select ${json}_object(${jsonColumns}) as ${__sql_sql_ts.sql.identifier("r")} from (${innerQuery.sql}) as ${__sql_sql_ts.sql.identifier("t")}) as ${__sql_sql_ts.sql.identifier(k)}` : __sql_sql_ts.sql`coalesce((select ${json}_group_array(json_object(${jsonColumns})) as ${__sql_sql_ts.sql.identifier("r")} from (${innerQuery.sql}) as ${__sql_sql_ts.sql.identifier("t")}), ${jsonb}_array()) as ${__sql_sql_ts.sql.identifier(k)}`;
			}), __sql_sql_ts.sql`, `);
		})() : void 0;
		const selectionArr = [
			columns,
			extras?.sql,
			joins
		].filter((e) => e !== void 0);
		if (!selectionArr.length) throw new __errors_ts.DrizzleError({ message: `No fields selected for table "${tableConfig.name}"${currentPath ? ` ("${currentPath}")` : ""}` });
		return {
			sql: __sql_sql_ts.sql`select ${__sql_sql_ts.sql.join(selectionArr, __sql_sql_ts.sql`, `)} from ${(0, __relations_ts.getTableAsAliasSQL)(table)}${throughJoin}${__sql_sql_ts.sql` where ${where}`.if(where)}${__sql_sql_ts.sql` order by ${order}`.if(order)}${__sql_sql_ts.sql` limit ${limit}`.if(limit !== void 0)}${__sql_sql_ts.sql` offset ${offset}`.if(offset !== void 0)}`,
			selection
		};
	}
};
var SQLiteSyncDialect = class extends SQLiteDialect {
	static [__entity_ts.entityKind] = "SQLiteSyncDialect";
	migrate(migrations, session, config) {
		const migrationsTable = config === void 0 ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const { newDb } = (0, __up_migrations_sqlite_ts.upgradeSyncIfNeeded)(migrationsTable, session, migrations);
		if (newDb) {
			const migrationTableCreate = __sql_sql_ts.sql`
			CREATE TABLE IF NOT EXISTS ${__sql_sql_ts.sql.identifier(migrationsTable)} (
				id INTEGER PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric,
				name text,
				applied_at TEXT
			)`;
			session.run(migrationTableCreate);
		}
		const dbMigrations = session.all(__sql_sql_ts.sql`SELECT id, hash, created_at, name FROM ${__sql_sql_ts.sql.identifier(migrationsTable)}`);
		if (typeof config === "object" && config.init) {
			if (dbMigrations.length) return { exitCode: "databaseMigrations" };
			if (migrations.length > 1) return { exitCode: "localMigrations" };
			const [migration] = migrations;
			if (!migration) return;
			session.run(__sql_sql_ts.sql`insert into ${__sql_sql_ts.sql.identifier(migrationsTable)} ("hash", "created_at", "name", "applied_at") values(${migration.hash}, ${migration.folderMillis}, ${migration.name}, ${(/* @__PURE__ */ new Date()).toISOString()})`);
			return;
		}
		const migrationsToRun = (0, __migrator_utils_ts.getMigrationsToRun)({
			localMigrations: migrations,
			dbMigrations
		});
		session.run(__sql_sql_ts.sql`BEGIN`);
		try {
			for (const migration of migrationsToRun) {
				for (const stmt of migration.sql) session.run(__sql_sql_ts.sql.raw(stmt));
				session.run(__sql_sql_ts.sql`INSERT INTO ${__sql_sql_ts.sql.identifier(migrationsTable)} ("hash", "created_at", "name", "applied_at") values(${migration.hash}, ${migration.folderMillis}, ${migration.name}, ${(/* @__PURE__ */ new Date()).toISOString()})`);
			}
			session.run(__sql_sql_ts.sql`COMMIT`);
		} catch (e) {
			session.run(__sql_sql_ts.sql`ROLLBACK`);
			throw e;
		}
	}
};
var SQLiteAsyncDialect = class extends SQLiteDialect {
	static [__entity_ts.entityKind] = "SQLiteAsyncDialect";
	async migrate(migrations, db, config) {
		const migrationsTable = config === void 0 ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const { newDb } = await (0, __up_migrations_sqlite_ts.upgradeAsyncIfNeeded)(migrationsTable, db, migrations);
		if (newDb) {
			const migrationTableCreate = __sql_sql_ts.sql`
			CREATE TABLE IF NOT EXISTS ${__sql_sql_ts.sql.identifier(migrationsTable)} (
				id INTEGER PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric,
				name text,
				applied_at TEXT
		)
		`;
			await db.session.run(migrationTableCreate);
		}
		const dbMigrations = await db.session.all(__sql_sql_ts.sql`SELECT id, hash, created_at, name FROM ${__sql_sql_ts.sql.identifier(migrationsTable)};`);
		if (typeof config === "object" && config.init) {
			if (dbMigrations.length) return { exitCode: "databaseMigrations" };
			if (migrations.length > 1) return { exitCode: "localMigrations" };
			const [migration] = migrations;
			if (!migration) return;
			await db.session.run(__sql_sql_ts.sql`insert into ${__sql_sql_ts.sql.identifier(migrationsTable)} ("hash", "created_at", "name", "applied_at") values(${migration.hash}, ${migration.folderMillis}, ${migration.name}, ${(/* @__PURE__ */ new Date()).toISOString()})`);
			return;
		}
		const migrationsToRun = (0, __migrator_utils_ts.getMigrationsToRun)({
			localMigrations: migrations,
			dbMigrations
		});
		await db.session.transaction(async (tx) => {
			for (const migration of migrationsToRun) {
				for (const stmt of migration.sql) await tx.run(__sql_sql_ts.sql.raw(stmt));
				await tx.run(__sql_sql_ts.sql`insert into ${__sql_sql_ts.sql.identifier(migrationsTable)} ("hash", "created_at", "name", "applied_at") values(${migration.hash}, ${migration.folderMillis}, ${migration.name}, ${(/* @__PURE__ */ new Date()).toISOString()})`);
			}
		});
	}
};

//#endregion
exports.SQLiteAsyncDialect = SQLiteAsyncDialect;
exports.SQLiteDialect = SQLiteDialect;
exports.SQLiteSyncDialect = SQLiteSyncDialect;
//# sourceMappingURL=dialect.cjs.map