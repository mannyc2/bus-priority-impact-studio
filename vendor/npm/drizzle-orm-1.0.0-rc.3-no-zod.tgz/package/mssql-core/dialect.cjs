Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
const require_runtime = require('../_virtual/_rolldown/runtime.cjs');
const require_view_common = require('../view-common.cjs');
const require_errors = require('../errors.cjs');
const require_sql_expressions_conditions = require('../sql/expressions/conditions.cjs');
const require_mssql_core_columns_common = require('./columns/common.cjs');
const require_mssql_core_table = require('./table.cjs');
const require_mssql_core_view_base = require('./view-base.cjs');
let __entity_ts = require("../entity.cjs");
let __subquery_ts = require("../subquery.cjs");
let __table_ts = require("../table.cjs");
let __column_ts = require("../column.cjs");
let __utils_ts = require("../utils.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let ___relations_ts = require("../_relations.cjs");
___relations_ts = require_runtime.__toESM(___relations_ts);
let __migrator_utils_ts = require("../migrator.utils.cjs");
let __alias_ts = require("../alias.cjs");
let __up_migrations_mssql_ts = require("../up-migrations/mssql.cjs");

//#region src/mssql-core/dialect.ts
var MsSqlDialect = class {
	static [__entity_ts.entityKind] = "MsSqlDialect";
	constructor(_config) {}
	async migrate(migrations, session, config) {
		const migrationsSchema = typeof config === "string" ? "drizzle" : config.migrationsSchema ?? "drizzle";
		const migrationSchemaCreate = __sql_sql_ts.sql`
			IF NOT EXISTS (
				SELECT 1 FROM sys.schemas WHERE name = ${migrationsSchema}
			)
			EXEC(\'CREATE SCHEMA ${__sql_sql_ts.sql.identifier(migrationsSchema)}\')
		`;
		await session.execute(migrationSchemaCreate);
		const migrationsTable = typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const { newDb } = await (0, __up_migrations_mssql_ts.upgradeIfNeeded)(migrationsSchema, migrationsTable, session, migrations);
		if (newDb) {
			const migrationTableCreate = __sql_sql_ts.sql`
			IF NOT EXISTS (
				SELECT 1 FROM INFORMATION_SCHEMA.TABLES 
				WHERE TABLE_NAME = ${migrationsTable} AND TABLE_SCHEMA = ${migrationsSchema}
			)
			CREATE TABLE ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)} (
				id bigint identity PRIMARY KEY,
				hash text NOT NULL,
				created_at bigint,
				name text,
				applied_at datetime2 NOT NULL DEFAULT GETUTCDATE()
			)
		`;
			await session.execute(migrationTableCreate);
		}
		const dbMigrations = (await session.execute(__sql_sql_ts.sql`select id, hash, created_at, name from ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)}`)).recordset;
		if (typeof config === "object" && config.init) {
			if (dbMigrations.length > 0) return { exitCode: "databaseMigrations" };
			if (migrations.length > 1) return { exitCode: "localMigrations" };
			const [migration] = migrations;
			if (!migration) return;
			await session.execute(__sql_sql_ts.sql`insert into ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)} ([hash], [created_at], [name]) values(${migration.hash}, ${migration.folderMillis}, ${migration.name})`);
			return;
		}
		const migrationsToRun = (0, __migrator_utils_ts.getMigrationsToRun)({
			localMigrations: migrations,
			dbMigrations
		});
		await session.transaction(async (tx) => {
			for (const migration of migrationsToRun) {
				for (const stmt of migration.sql) await tx.execute(__sql_sql_ts.sql.raw(stmt));
				await tx.execute(__sql_sql_ts.sql`insert into ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)} ([hash], [created_at], [name]) values(${migration.hash}, ${migration.folderMillis}, ${migration.name})`);
			}
		});
	}
	escapeName(name) {
		return `[${name.replace(/\]/g, "]]")}]`;
	}
	escapeParam(_num) {
		return `@par${_num}`;
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildDeleteQuery({ table, where, output }) {
		return __sql_sql_ts.sql`delete from ${table}${output ? __sql_sql_ts.sql` output ${this.buildSelectionOutput(output, { type: "DELETED" })}` : void 0}${where ? __sql_sql_ts.sql` where ${where}` : void 0}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[__table_ts.Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setSize = columnNames.length;
		return __sql_sql_ts.sql.join(columnNames.flatMap((colName, i) => {
			const col = tableColumns[colName];
			const onUpdateFnResult = col.onUpdateFn?.();
			const value = set[colName] ?? ((0, __entity_ts.is)(onUpdateFnResult, __sql_sql_ts.SQL) ? onUpdateFnResult : __sql_sql_ts.sql.param(onUpdateFnResult, col));
			const res = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}`;
			if (i < setSize - 1) return [res, __sql_sql_ts.sql.raw(", ")];
			return [res];
		}));
	}
	buildUpdateQuery({ table, set, where, output }) {
		const setSql = this.buildUpdateSet(table, set);
		const outputSql = __sql_sql_ts.sql``;
		if (output) {
			outputSql.append(__sql_sql_ts.sql` output `);
			if (output.inserted) outputSql.append(this.buildSelectionOutput(output.inserted, { type: "INSERTED" }));
			if (output.deleted) {
				if (output.inserted) outputSql.append(__sql_sql_ts.sql`, `);
				outputSql.append(this.buildSelectionOutput(output.deleted, { type: "DELETED" }));
			}
		}
		return __sql_sql_ts.sql`update ${table} set ${setSql}${outputSql}${where ? __sql_sql_ts.sql` where ${where}` : void 0}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false } = {}) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) && field.isSelectionField) {
				if (!isSingleTable && field.origin !== void 0) chunk.push(__sql_sql_ts.sql.identifier(field.origin), __sql_sql_ts.sql.raw("."));
				chunk.push(__sql_sql_ts.sql.identifier(field.fieldAlias));
			} else if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) || (0, __entity_ts.is)(field, __sql_sql_ts.SQL)) {
				const query = (0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) ? field.sql : field;
				if (isSingleTable) {
					const newSql = new __sql_sql_ts.SQL(query.queryChunks.map((c) => {
						if ((0, __entity_ts.is)(c, require_mssql_core_columns_common.MsSqlColumn)) return __sql_sql_ts.sql.identifier(c.name);
						return c;
					}));
					chunk.push(query.shouldInlineParams ? newSql.inlineParams() : newSql);
				} else chunk.push(query);
				if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased)) chunk.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
			} else if ((0, __entity_ts.is)(field, __column_ts.Column)) if (isSingleTable) chunk.push(field.isAlias ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name)} as ${field}` : __sql_sql_ts.sql.identifier(field.name));
			else chunk.push(field.isAlias ? __sql_sql_ts.sql`${(0, __alias_ts.getOriginalColumnFromAlias)(field)} as ${field}` : field);
			else if ((0, __entity_ts.is)(field, __subquery_ts.Subquery)) {
				const entries = Object.entries(field._.selectedFields);
				if (entries.length === 1) {
					const entry = entries[0][1];
					const fieldDecoder = (0, __entity_ts.is)(entry, __sql_sql_ts.SQL) ? entry.decoder : (0, __entity_ts.is)(entry, __column_ts.Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
					if (fieldDecoder) field._.sql.decoder = fieldDecoder;
				}
				chunk.push(field);
			}
			if (i < columnsLen - 1) chunk.push(__sql_sql_ts.sql`, `);
			return chunk;
		});
		return __sql_sql_ts.sql.join(chunks);
	}
	buildSelectionOutput(fields, { type }) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) && field.isSelectionField) chunk.push(__sql_sql_ts.sql.join([__sql_sql_ts.sql.raw(`${type}.`), __sql_sql_ts.sql.identifier(field.fieldAlias)]));
			else if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) || (0, __entity_ts.is)(field, __sql_sql_ts.SQL)) {
				const query = (0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) ? field.sql : field;
				chunk.push(new __sql_sql_ts.SQL(query.queryChunks.map((c) => {
					if ((0, __entity_ts.is)(c, require_mssql_core_columns_common.MsSqlColumn)) return __sql_sql_ts.sql.join([__sql_sql_ts.sql.raw(`${type}.`), __sql_sql_ts.sql.identifier(c.name)]);
					return c;
				})));
				if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased)) chunk.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
			} else if ((0, __entity_ts.is)(field, __column_ts.Column)) chunk.push(__sql_sql_ts.sql.join([__sql_sql_ts.sql.raw(`${type}.`), field.isAlias ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name)} as ${field}` : __sql_sql_ts.sql.identifier(field.name)]));
			if (i < columnsLen - 1) chunk.push(__sql_sql_ts.sql`, `);
			return chunk;
		});
		return __sql_sql_ts.sql.join(chunks);
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, fetch, for: _for, top, offset, distinct, setOperators }) {
		const fieldsList = fieldsFlat ?? (0, __utils_ts.orderSelectedFields)(fields);
		for (const f of fieldsList) if ((0, __entity_ts.is)(f.field, __column_ts.Column) && (0, __table_ts.getTableName)(f.field.table) !== ((0, __entity_ts.is)(table, __subquery_ts.Subquery) ? table._.alias : (0, __entity_ts.is)(table, require_mssql_core_view_base.MsSqlViewBase) ? table[require_view_common.ViewBaseConfig].name : (0, __entity_ts.is)(table, __sql_sql_ts.SQL) ? void 0 : (0, __table_ts.getTableName)(table)) && !((table) => joins?.some(({ alias }) => alias === (table[__table_ts.Table.Symbol.IsAlias] ? (0, __table_ts.getTableName)(table) : table[__table_ts.Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = (0, __table_ts.getTableName)(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		let withSql;
		if (withList?.length) {
			const withSqlChunks = [__sql_sql_ts.sql`with `];
			for (const [i, w] of withList.entries()) {
				withSqlChunks.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql})`);
				if (i < withList.length - 1) withSqlChunks.push(__sql_sql_ts.sql`, `);
			}
			withSqlChunks.push(__sql_sql_ts.sql` `);
			withSql = __sql_sql_ts.sql.join(withSqlChunks);
		}
		const distinctSql = distinct ? __sql_sql_ts.sql` distinct` : void 0;
		const topSql = top ? __sql_sql_ts.sql` top(${top})` : void 0;
		const selection = this.buildSelection(fieldsList, { isSingleTable });
		const tableSql = (() => {
			if ((0, __entity_ts.is)(table, __table_ts.Table) && table[__table_ts.Table.Symbol.OriginalName] !== table[__table_ts.Table.Symbol.Name]) {
				let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.OriginalName])} ${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Name])}`;
				if (table[__table_ts.Table.Symbol.Schema]) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Schema])}.${fullName}`;
				return fullName;
			}
			if ((0, __entity_ts.is)(table, __sql_sql_ts.View) && table[require_view_common.ViewBaseConfig].isAlias) {
				let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[require_view_common.ViewBaseConfig].originalName)}`;
				if (table[require_view_common.ViewBaseConfig].schema) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[require_view_common.ViewBaseConfig].schema)}.${fullName}`;
				return __sql_sql_ts.sql`${fullName} ${__sql_sql_ts.sql.identifier(table[require_view_common.ViewBaseConfig].name)}`;
			}
			return table;
		})();
		const joinsArray = [];
		if (joins) for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(__sql_sql_ts.sql` `);
			const table = joinMeta.table;
			const lateralSql = joinMeta.lateral ? __sql_sql_ts.sql` lateral` : void 0;
			if ((0, __entity_ts.is)(table, require_mssql_core_table.MsSqlTable)) {
				const tableName = table[require_mssql_core_table.MsSqlTable.Symbol.Name];
				const tableSchema = table[require_mssql_core_table.MsSqlTable.Symbol.Schema];
				const origTableName = table[require_mssql_core_table.MsSqlTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(tableSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origTableName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`} on ${joinMeta.on}`);
			} else if ((0, __entity_ts.is)(table, __sql_sql_ts.View)) {
				const viewName = table[require_view_common.ViewBaseConfig].name;
				const viewSchema = table[require_view_common.ViewBaseConfig].schema;
				const origViewName = table[require_view_common.ViewBaseConfig].originalName;
				const alias = viewName === origViewName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(viewSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origViewName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`} on ${joinMeta.on}`);
			} else joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join${lateralSql} ${table} on ${joinMeta.on}`);
			if (index < joins.length - 1) joinsArray.push(__sql_sql_ts.sql` `);
		}
		const joinsSql = __sql_sql_ts.sql.join(joinsArray);
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const havingSql = having ? __sql_sql_ts.sql` having ${having}` : void 0;
		let orderBySql;
		if (orderBy && orderBy.length > 0) orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderBy, __sql_sql_ts.sql`, `)}`;
		let groupBySql;
		if (groupBy && groupBy.length > 0) groupBySql = __sql_sql_ts.sql` group by ${__sql_sql_ts.sql.join(groupBy, __sql_sql_ts.sql`, `)}`;
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset} rows`;
		const fetchSql = fetch === void 0 ? void 0 : __sql_sql_ts.sql` fetch next ${fetch} rows only`;
		let forSQL;
		if (_for && _for.mode === "json") forSQL = __sql_sql_ts.sql` for json ${__sql_sql_ts.sql.raw(_for.type)}${_for.options?.root ? __sql_sql_ts.sql` root(${__sql_sql_ts.sql.identifier(_for.options.root)})` : void 0}${_for.options?.includeNullValues ? __sql_sql_ts.sql` include_null_values` : void 0}${_for.options?.withoutArrayWrapper ? __sql_sql_ts.sql` without_array_wrapper` : void 0}`;
		const finalQuery = __sql_sql_ts.sql`${withSql}select${distinctSql}${topSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${offsetSql}${fetchSql}${forSQL}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		const [setOperator, ...rest] = setOperators;
		if (!setOperator) throw new Error("Cannot pass undefined values to any set operator");
		if (rest.length === 0) return this.buildSetOperationQuery({
			leftSelect,
			setOperator
		});
		return this.buildSetOperations(this.buildSetOperationQuery({
			leftSelect,
			setOperator
		}), rest);
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, fetch, orderBy, offset } }) {
		const leftChunk = __sql_sql_ts.sql`(${leftSelect.getSQL()}) `;
		const rightChunk = __sql_sql_ts.sql`(${rightSelect.getSQL()})`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const orderByUnit of orderBy) if ((0, __entity_ts.is)(orderByUnit, require_mssql_core_columns_common.MsSqlColumn)) orderByValues.push(__sql_sql_ts.sql.identifier(orderByUnit.name));
			else if ((0, __entity_ts.is)(orderByUnit, __sql_sql_ts.SQL)) {
				for (let i = 0; i < orderByUnit.queryChunks.length; i++) {
					const chunk = orderByUnit.queryChunks[i];
					if ((0, __entity_ts.is)(chunk, require_mssql_core_columns_common.MsSqlColumn)) orderByUnit.queryChunks[i] = __sql_sql_ts.sql.identifier(chunk.name);
				}
				orderByValues.push(__sql_sql_ts.sql`${orderByUnit}`);
			} else orderByValues.push(__sql_sql_ts.sql`${orderByUnit}`);
			orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByValues, __sql_sql_ts.sql`, `)} `;
		}
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset} rows`;
		const fetchSql = fetch === void 0 ? void 0 : __sql_sql_ts.sql` fetch next ${fetch} rows only`;
		return __sql_sql_ts.sql`${leftChunk}${__sql_sql_ts.sql.raw(`${type} ${isAll ? "all " : ""}`)}${rightChunk}${orderBySql}${offsetSql}${fetchSql}`;
	}
	buildInsertQuery({ table, values, output }) {
		const valuesSqlList = [];
		const columns = table[__table_ts.Table.Symbol.Columns];
		const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrder = colEntries.map(([, column]) => __sql_sql_ts.sql.identifier(column.name));
		for (const [valueIndex, value] of values.entries()) {
			const valueList = [];
			for (const [fieldName, col] of colEntries) {
				const colValue = value[fieldName];
				if (colValue === void 0 || (0, __entity_ts.is)(colValue, __sql_sql_ts.Param) && colValue.value === void 0) if (col.defaultFn !== void 0) {
					const defaultFnResult = col.defaultFn();
					const defaultValue = (0, __entity_ts.is)(defaultFnResult, __sql_sql_ts.SQL) ? defaultFnResult : __sql_sql_ts.sql.param(defaultFnResult, col);
					valueList.push(defaultValue);
				} else if (!col.default && col.onUpdateFn !== void 0) {
					const onUpdateFnResult = col.onUpdateFn();
					const newValue = (0, __entity_ts.is)(onUpdateFnResult, __sql_sql_ts.SQL) ? onUpdateFnResult : __sql_sql_ts.sql.param(onUpdateFnResult, col);
					valueList.push(newValue);
				} else valueList.push(__sql_sql_ts.sql`default`);
				else valueList.push(colValue);
			}
			valuesSqlList.push(valueList);
			if (valueIndex < values.length - 1) valuesSqlList.push(__sql_sql_ts.sql`, `);
		}
		const valuesSql = insertOrder.length === 0 ? void 0 : __sql_sql_ts.sql.join(valuesSqlList);
		const outputSql = output ? __sql_sql_ts.sql` output ${this.buildSelectionOutput(output, { type: "INSERTED" })}` : void 0;
		return __sql_sql_ts.sql`insert into ${table} ${insertOrder.length === 0 ? __sql_sql_ts.sql`default` : insertOrder}${outputSql} values ${valuesSql}`;
	}
	sqlToQuery(sql, invokeSource) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			invokeSource
		});
	}
	buildRelationalQuery({ fullSchema, schema, tableNamesMap, table, tableConfig, queryConfig: config, tableAlias, nestedQueryRelation, joinOn }) {
		let selection = [];
		let limit, offset, orderBy = [], where;
		if (config === true) selection = Object.entries(tableConfig.columns).map(([key, value]) => ({
			dbKey: value.name,
			tsKey: key,
			field: (0, __alias_ts.aliasedTableColumn)(value, tableAlias),
			relationTableTsKey: void 0,
			isJson: false,
			selection: []
		}));
		else {
			const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [key, (0, __alias_ts.aliasedTableColumn)(value, tableAlias)]));
			if (config.where) {
				const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, ___relations_ts.getOperators()) : config.where;
				where = whereSql && (0, __alias_ts.mapColumnsInSQLToAlias)(whereSql, tableAlias);
			}
			const fieldsSelection = [];
			let selectedColumns = [];
			if (config.columns) {
				let isIncludeMode = false;
				for (const [field, value] of Object.entries(config.columns)) {
					if (value === void 0) continue;
					if (field in tableConfig.columns) {
						if (!isIncludeMode && value === true) isIncludeMode = true;
						selectedColumns.push(field);
					}
				}
				if (selectedColumns.length > 0) selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
			} else selectedColumns = Object.keys(tableConfig.columns);
			for (const field of selectedColumns) {
				const column = tableConfig.columns[field];
				fieldsSelection.push({
					tsKey: field,
					value: column
				});
			}
			let selectedRelations = [];
			if (config.with) selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({
				tsKey,
				queryConfig,
				relation: tableConfig.relations[tsKey]
			}));
			let extras;
			if (config.extras) {
				extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql: __sql_sql_ts.sql }) : config.extras;
				for (const [tsKey, value] of Object.entries(extras)) fieldsSelection.push({
					tsKey,
					value: (0, __alias_ts.mapColumnsInAliasedSQLToAlias)(value, tableAlias)
				});
			}
			for (const { tsKey, value } of fieldsSelection) selection.push({
				dbKey: (0, __entity_ts.is)(value, __sql_sql_ts.SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
				tsKey,
				field: (0, __entity_ts.is)(value, __column_ts.Column) ? (0, __alias_ts.aliasedTableColumn)(value, tableAlias) : value,
				relationTableTsKey: void 0,
				isJson: false,
				selection: []
			});
			let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, ___relations_ts.getOrderByOperators()) : config.orderBy ?? [];
			if (!Array.isArray(orderByOrig)) orderByOrig = [orderByOrig];
			orderBy = orderByOrig.map((orderByValue) => {
				if ((0, __entity_ts.is)(orderByValue, __column_ts.Column)) return (0, __alias_ts.aliasedTableColumn)(orderByValue, tableAlias);
				return (0, __alias_ts.mapColumnsInSQLToAlias)(orderByValue, tableAlias);
			});
			limit = config.limit;
			offset = config.offset;
			for (const { tsKey: selectedRelationTsKey, queryConfig: selectedRelationConfigValue, relation } of selectedRelations) {
				const normalizedRelation = ___relations_ts.normalizeRelation(schema, tableNamesMap, relation);
				const relationTableTsName = tableNamesMap[(0, __table_ts.getTableUniqueName)(relation.referencedTable)];
				const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
				const joinOn = require_sql_expressions_conditions.and(...normalizedRelation.fields.map((field, i) => require_sql_expressions_conditions.eq((0, __alias_ts.aliasedTableColumn)(normalizedRelation.references[i], relationTableAlias), (0, __alias_ts.aliasedTableColumn)(field, tableAlias))));
				const builtRelation = this.buildRelationalQuery({
					fullSchema,
					schema,
					tableNamesMap,
					table: fullSchema[relationTableTsName],
					tableConfig: schema[relationTableTsName],
					queryConfig: (0, __entity_ts.is)(relation, ___relations_ts.One) ? selectedRelationConfigValue === true ? { limit: 1 } : {
						...selectedRelationConfigValue,
						limit: 1
					} : selectedRelationConfigValue,
					tableAlias: relationTableAlias,
					joinOn,
					nestedQueryRelation: relation
				});
				let fieldSql = __sql_sql_ts.sql`(${builtRelation.sql} for json auto, include_null_values)${nestedQueryRelation ? __sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(relationTableAlias)}` : void 0}`;
				if ((0, __entity_ts.is)(relation, ___relations_ts.Many)) fieldSql = __sql_sql_ts.sql`${fieldSql}`;
				const field = fieldSql.as(selectedRelationTsKey);
				selection.push({
					dbKey: selectedRelationTsKey,
					tsKey: selectedRelationTsKey,
					field,
					relationTableTsKey: relationTableTsName,
					isJson: true,
					selection: builtRelation.selection
				});
			}
		}
		if (selection.length === 0) throw new require_errors.DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.` });
		let result;
		where = require_sql_expressions_conditions.and(joinOn, where);
		if (nestedQueryRelation) {
			let field = __sql_sql_ts.sql`${__sql_sql_ts.sql.join(selection.map((sel) => {
				return (0, __entity_ts.is)(sel.field, require_mssql_core_columns_common.MsSqlColumn) ? __sql_sql_ts.sql.identifier(sel.field.name) : (0, __entity_ts.is)(sel.field, __sql_sql_ts.SQL.Aliased) ? sel.isJson ? sel.field.sql : __sql_sql_ts.sql`${sel.field.sql} as ${__sql_sql_ts.sql.identifier(sel.field.fieldAlias)}` : sel.field;
			}), __sql_sql_ts.sql`, `)}`;
			if ((0, __entity_ts.is)(nestedQueryRelation, ___relations_ts.Many)) field = __sql_sql_ts.sql`${field}`;
			const nestedSelection = [{
				dbKey: "data",
				tsKey: "data",
				field,
				isJson: true,
				relationTableTsKey: tableConfig.tsName,
				selection
			}];
			result = (0, __alias_ts.aliasedTable)(table, tableAlias);
			const top = offset ? void 0 : limit ?? void 0;
			const fetch = offset && limit ? limit : void 0;
			if (orderBy.length === 0 && offset !== void 0 && fetch !== void 0) orderBy = [__sql_sql_ts.sql`1`];
			result = this.buildSelectQuery({
				table: (0, __entity_ts.is)(result, require_mssql_core_table.MsSqlTable) ? result : new __subquery_ts.Subquery(result, {}, tableAlias),
				fields: {},
				fieldsFlat: nestedSelection.map(({ field }) => ({
					path: [],
					field: (0, __entity_ts.is)(field, __column_ts.Column) ? (0, __alias_ts.aliasedTableColumn)(field, tableAlias) : field
				})),
				where,
				top,
				offset,
				fetch,
				orderBy,
				setOperators: []
			});
		} else {
			const top = offset ? void 0 : limit ?? void 0;
			const fetch = offset && limit ? limit : void 0;
			if (orderBy.length === 0 && offset !== void 0 && fetch !== void 0) orderBy = [__sql_sql_ts.sql`1`];
			result = this.buildSelectQuery({
				table: (0, __alias_ts.aliasedTable)(table, tableAlias),
				fields: {},
				fieldsFlat: selection.map(({ field }) => ({
					path: [],
					field: (0, __entity_ts.is)(field, __column_ts.Column) ? (0, __alias_ts.aliasedTableColumn)(field, tableAlias) : field
				})),
				where,
				top,
				offset,
				fetch,
				orderBy,
				setOperators: []
			});
		}
		return {
			tableTsKey: tableConfig.tsName,
			sql: result,
			selection
		};
	}
};

//#endregion
exports.MsSqlDialect = MsSqlDialect;
//# sourceMappingURL=dialect.cjs.map