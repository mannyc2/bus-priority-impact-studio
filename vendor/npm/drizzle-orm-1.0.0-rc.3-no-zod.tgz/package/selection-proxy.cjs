Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
const require_entity = require('./entity.cjs');
const require_subquery = require('./subquery.cjs');
const require_column = require('./column.cjs');
const require_sql_sql = require('./sql/sql.cjs');
const require_view_common = require('./view-common.cjs');
const require_alias = require('./alias.cjs');

//#region src/selection-proxy.ts
var SelectionProxyHandler = class SelectionProxyHandler {
	static [require_entity.entityKind] = "SelectionProxyHandler";
	config;
	constructor(config) {
		this.config = { ...config };
	}
	get(subquery, prop) {
		if (prop === "_") return {
			...subquery["_"],
			selectedFields: new Proxy(subquery._.selectedFields, this)
		};
		if (prop === require_view_common.ViewBaseConfig) return {
			...subquery[require_view_common.ViewBaseConfig],
			selectedFields: new Proxy(subquery[require_view_common.ViewBaseConfig].selectedFields, this)
		};
		if (typeof prop === "symbol") return subquery[prop];
		const value = (require_entity.is(subquery, require_subquery.Subquery) ? subquery._.selectedFields : require_entity.is(subquery, require_sql_sql.View) ? subquery[require_view_common.ViewBaseConfig].selectedFields : subquery)[prop];
		if (require_entity.is(value, require_sql_sql.SQL.Aliased)) {
			if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) return value.sql;
			const newValue = value.clone();
			newValue.isSelectionField = true;
			newValue.origin = this.config.alias;
			return newValue;
		}
		if (require_entity.is(value, require_sql_sql.SQL)) {
			if (this.config.sqlBehavior === "sql") return value;
			throw new Error(`You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`);
		}
		if (require_entity.is(value, require_column.Column)) {
			if (this.config.alias) return new Proxy(value, new require_alias.ColumnTableAliasProxyHandler(new Proxy(value.table, new require_alias.TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false, true)), true));
			return value;
		}
		if (typeof value !== "object" || value === null) return value;
		return new Proxy(value, new SelectionProxyHandler(this.config));
	}
};

//#endregion
exports.SelectionProxyHandler = SelectionProxyHandler;
//# sourceMappingURL=selection-proxy.cjs.map