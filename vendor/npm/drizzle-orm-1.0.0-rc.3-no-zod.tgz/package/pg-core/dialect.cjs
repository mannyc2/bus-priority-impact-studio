Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
const require_runtime = require('../_virtual/_rolldown/runtime.cjs');
const require_pg_core_codecs = require('./codecs.cjs');
const require_pg_core_view_base = require('./view-base.cjs');
let __entity_ts = require("../entity.cjs");
let __subquery_ts = require("../subquery.cjs");
let __view_common_ts = require("../view-common.cjs");
let __table_ts = require("../table.cjs");
let __column_ts = require("../column.cjs");
let __utils_ts = require("../utils.cjs");
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __relations_ts = require("../relations.cjs");
let __sql_index_ts = require("../sql/index.cjs");
let __errors_ts = require("../errors.cjs");
let __alias_ts = require("../alias.cjs");
let __pg_core_table_ts = require("./table.cjs");
let __pg_core_columns_index_ts = require("./columns/index.cjs");

//#region src/pg-core/dialect.ts
var PgDialect = class {
	static [__entity_ts.entityKind] = "PgDialect";
	codecs;
	mapperGenerators;
	constructor(config) {
		this.codecs = new __codecs_ts.CodecsCollection(require_pg_core_codecs.resolvePgTypeAlias, config?.codecs);
		this.mapperGenerators = config?.useJitMappers ? {
			rows: __utils_ts.makeJitQueryMapper,
			relationalRows: __relations_ts.makeJitRqbMapper
		} : {
			rows: __utils_ts.makeDefaultQueryMapper,
			relationalRows: __relations_ts.makeDefaultRqbMapper
		};
	}
	escapeName(name) {
		return `"${name.replace(/"/g, "\"\"")}"`;
	}
	escapeParam(num) {
		return `$${num + 1}`;
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const withSqlChunks = [__sql_sql_ts.sql`with `];
		for (const [i, w] of queries.entries()) {
			withSqlChunks.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql})`);
			if (i < queries.length - 1) withSqlChunks.push(__sql_sql_ts.sql`, `);
		}
		withSqlChunks.push(__sql_sql_ts.sql` `);
		return __sql_sql_ts.sql.join(withSqlChunks);
	}
	buildDeleteQuery({ table, where, returning, withList, comment, ignoreSelectionCastCodecs }) {
		const withSql = this.buildWithCTE(withList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: true,
			ignoreCastCodecs: ignoreSelectionCastCodecs
		})}` : void 0;
		return __sql_sql_ts.sql`${withSql}delete from ${table}${where ? __sql_sql_ts.sql` where ${where}` : void 0}${returningSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[__table_ts.Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setLength = columnNames.length;
		return __sql_sql_ts.sql.join(columnNames.flatMap((colName, i) => {
			const col = tableColumns[colName];
			const onUpdateFnResult = col.onUpdateFn?.();
			const value = set[colName] ?? ((0, __entity_ts.is)(onUpdateFnResult, __sql_sql_ts.SQL) ? onUpdateFnResult : __sql_sql_ts.sql.param(onUpdateFnResult, col));
			const res = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}`;
			if (i < setLength - 1) return [res, __sql_sql_ts.sql.raw(", ")];
			return [res];
		}));
	}
	buildUpdateQuery({ table, set, where, returning, withList, from, joins, comment, ignoreSelectionCastCodecs }) {
		const withSql = this.buildWithCTE(withList);
		const tableName = table[__pg_core_table_ts.PgTable.Symbol.Name];
		const tableSchema = table[__pg_core_table_ts.PgTable.Symbol.Schema];
		const origTableName = table[__pg_core_table_ts.PgTable.Symbol.OriginalName];
		const alias = tableName === origTableName ? void 0 : tableName;
		const tableSql = __sql_sql_ts.sql`${tableSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(tableSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origTableName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}`;
		const setSql = this.buildUpdateSet(table, set);
		const fromSql = from && __sql_sql_ts.sql.join([__sql_sql_ts.sql.raw(" from "), this.buildFromTable(from)]);
		const joinsSql = this.buildJoins(joins);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: !from,
			ignoreCastCodecs: ignoreSelectionCastCodecs
		})}` : void 0;
		return __sql_sql_ts.sql`${withSql}update ${tableSql} set ${setSql}${fromSql}${joinsSql}${where ? __sql_sql_ts.sql` where ${where}` : void 0}${returningSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false, ignoreCastCodecs = false } = {}) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) && field.isSelectionField) {
				if (!isSingleTable && field.origin !== void 0) chunk.push(__sql_sql_ts.sql.identifier(field.origin), __sql_sql_ts.sql.raw("."));
				chunk.push(__sql_sql_ts.sql.identifier(field.fieldAlias));
			} else if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) || (0, __entity_ts.is)(field, __sql_sql_ts.SQL)) {
				const query = (0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased) ? field.sql : field;
				if (isSingleTable) {
					const newSql = new __sql_sql_ts.SQL(query.queryChunks.map((c) => {
						if ((0, __entity_ts.is)(c, __pg_core_columns_index_ts.PgColumn)) return __sql_sql_ts.sql.identifier(c.name);
						return c;
					}));
					chunk.push(query.shouldInlineParams ? newSql.inlineParams() : newSql);
				} else chunk.push(query);
				if ((0, __entity_ts.is)(field, __sql_sql_ts.SQL.Aliased)) chunk.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
			} else if ((0, __entity_ts.is)(field, __column_ts.Column)) {
				let name;
				if (isSingleTable) name = field.isAlias ? __sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name) : __sql_sql_ts.sql.identifier(field.name);
				else name = field.isAlias ? (0, __alias_ts.getOriginalColumnFromAlias)(field) : field;
				const casted = ignoreCastCodecs ? name : this.codecs.apply(field, "cast", name);
				chunk.push(field.isAlias ? __sql_sql_ts.sql`${casted} as ${field}` : casted);
			} else if ((0, __entity_ts.is)(field, __subquery_ts.Subquery)) {
				const entries = Object.entries(field._.selectedFields);
				if (entries.length === 1) {
					const entry = entries[0][1];
					const fieldDecoder = (0, __entity_ts.is)(entry, __sql_sql_ts.SQL) ? entry.decoder : (0, __entity_ts.is)(entry, __column_ts.Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
					if (fieldDecoder) field._.sql.decoder = fieldDecoder;
				}
				chunk.push(field);
			}
			if (i < columnsLen - 1) chunk.push(__sql_sql_ts.sql`, `);
			return chunk;
		});
		return __sql_sql_ts.sql.join(chunks);
	}
	buildJoins(joins) {
		if (!joins || joins.length === 0) return;
		const joinsArray = [];
		for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(__sql_sql_ts.sql` `);
			const table = joinMeta.table;
			const lateralSql = joinMeta.lateral ? __sql_sql_ts.sql` lateral` : void 0;
			const onSql = joinMeta.on ? __sql_sql_ts.sql` on ${joinMeta.on}` : void 0;
			if ((0, __entity_ts.is)(table, __pg_core_table_ts.PgTable)) {
				const tableName = table[__pg_core_table_ts.PgTable.Symbol.Name];
				const tableSchema = table[__pg_core_table_ts.PgTable.Symbol.Schema];
				const origTableName = table[__pg_core_table_ts.PgTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(tableSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origTableName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}${onSql}`);
			} else if ((0, __entity_ts.is)(table, __sql_index_ts.View)) {
				const viewName = table[__view_common_ts.ViewBaseConfig].name;
				const viewSchema = table[__view_common_ts.ViewBaseConfig].schema;
				const origViewName = table[__view_common_ts.ViewBaseConfig].originalName;
				const alias = viewName === origViewName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(viewSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origViewName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}${onSql}`);
			} else joinsArray.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.raw(joinMeta.joinType)} join${lateralSql} ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(__sql_sql_ts.sql` `);
		}
		return __sql_sql_ts.sql.join(joinsArray);
	}
	buildFromTable(table) {
		if ((0, __entity_ts.is)(table, __table_ts.Table) && table[__table_ts.Table.Symbol.IsAlias]) {
			let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.OriginalName])}`;
			if (table[__table_ts.Table.Symbol.Schema]) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Schema])}.${fullName}`;
			return __sql_sql_ts.sql`${fullName} ${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Name])}`;
		}
		if ((0, __entity_ts.is)(table, __sql_index_ts.View) && table[__view_common_ts.ViewBaseConfig].isAlias) {
			let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].originalName)}`;
			if (table[__view_common_ts.ViewBaseConfig].schema) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].schema)}.${fullName}`;
			return __sql_sql_ts.sql`${fullName} ${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].name)}`;
		}
		return table;
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, limit, offset, lockingClause, distinct, setOperators, comment, ignoreSelectionCastCodecs }) {
		const fieldsList = fieldsFlat ?? (0, __utils_ts.orderSelectedFields)(fields, void 0, this.codecs);
		for (const f of fieldsList) if ((0, __entity_ts.is)(f.field, __column_ts.Column) && (0, __table_ts.getTableName)(f.field.table) !== ((0, __entity_ts.is)(table, __subquery_ts.Subquery) ? table._.alias : (0, __entity_ts.is)(table, require_pg_core_view_base.PgViewBase) ? table[__view_common_ts.ViewBaseConfig].name : (0, __entity_ts.is)(table, __sql_sql_ts.SQL) ? void 0 : (0, __table_ts.getTableName)(table)) && !((table) => joins?.some(({ alias }) => alias === (table[__table_ts.Table.Symbol.IsAlias] ? (0, __table_ts.getTableName)(table) : table[__table_ts.Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = (0, __table_ts.getTableName)(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		let distinctSql;
		if (distinct) distinctSql = distinct === true ? __sql_sql_ts.sql` distinct` : __sql_sql_ts.sql` distinct on (${__sql_sql_ts.sql.join(distinct.on, __sql_sql_ts.sql`, `)})`;
		const selection = this.buildSelection(fieldsList, {
			isSingleTable,
			ignoreCastCodecs: ignoreSelectionCastCodecs
		});
		const tableSql = this.buildFromTable(table);
		const joinsSql = this.buildJoins(joins);
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const havingSql = having ? __sql_sql_ts.sql` having ${having}` : void 0;
		let orderBySql;
		if (orderBy && orderBy.length > 0) orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderBy, __sql_sql_ts.sql`, `)}`;
		let groupBySql;
		if (groupBy && groupBy.length > 0) groupBySql = __sql_sql_ts.sql` group by ${__sql_sql_ts.sql.join(groupBy, __sql_sql_ts.sql`, `)}`;
		const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? __sql_sql_ts.sql` limit ${limit}` : void 0;
		const offsetSql = offset ? __sql_sql_ts.sql` offset ${offset}` : void 0;
		const lockingClauseSql = __sql_sql_ts.sql.empty();
		if (lockingClause) {
			const clauseSql = __sql_sql_ts.sql` for ${__sql_sql_ts.sql.raw(lockingClause.strength)}`;
			if (lockingClause.config.of) clauseSql.append(__sql_sql_ts.sql` of ${__sql_sql_ts.sql.join(Array.isArray(lockingClause.config.of) ? lockingClause.config.of.map((it) => __sql_sql_ts.sql.identifier(it[__pg_core_table_ts.PgTable.Symbol.Name])) : [__sql_sql_ts.sql.identifier(lockingClause.config.of[__pg_core_table_ts.PgTable.Symbol.Name])], __sql_sql_ts.sql`, `)}`);
			if (lockingClause.config.noWait) clauseSql.append(__sql_sql_ts.sql` nowait`);
			else if (lockingClause.config.skipLocked) clauseSql.append(__sql_sql_ts.sql` skip locked`);
			lockingClauseSql.append(clauseSql);
		}
		const finalQuery = __sql_sql_ts.sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}${lockingClauseSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		const [setOperator, ...rest] = setOperators;
		if (!setOperator) throw new Error("Cannot pass undefined values to any set operator");
		if (rest.length === 0) return this.buildSetOperationQuery({
			leftSelect,
			setOperator
		});
		return this.buildSetOperations(this.buildSetOperationQuery({
			leftSelect,
			setOperator
		}), rest);
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, limit, orderBy, offset } }) {
		const leftChunk = __sql_sql_ts.sql`(${leftSelect.getSQL()}) `;
		const rightChunk = __sql_sql_ts.sql`(${rightSelect.getSQL()})`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const singleOrderBy of orderBy) if ((0, __entity_ts.is)(singleOrderBy, __pg_core_columns_index_ts.PgColumn)) orderByValues.push(__sql_sql_ts.sql.identifier(singleOrderBy.name));
			else if ((0, __entity_ts.is)(singleOrderBy, __sql_sql_ts.SQL)) {
				for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
					const chunk = singleOrderBy.queryChunks[i];
					if ((0, __entity_ts.is)(chunk, __pg_core_columns_index_ts.PgColumn)) singleOrderBy.queryChunks[i] = __sql_sql_ts.sql.identifier(chunk.name);
				}
				orderByValues.push(__sql_sql_ts.sql`${singleOrderBy}`);
			} else orderByValues.push(__sql_sql_ts.sql`${singleOrderBy}`);
			orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByValues, __sql_sql_ts.sql`, `)} `;
		}
		const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? __sql_sql_ts.sql` limit ${limit}` : void 0;
		const operatorChunk = __sql_sql_ts.sql.raw(`${type} ${isAll ? "all " : ""}`);
		const offsetSql = offset ? __sql_sql_ts.sql` offset ${offset}` : void 0;
		return __sql_sql_ts.sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select, overridingSystemValue_, comment, ignoreSelectionCastCodecs }) {
		const valuesSqlList = [];
		const columns = table[__table_ts.Table.Symbol.Columns];
		const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrder = colEntries.map(([, column]) => __sql_sql_ts.sql.identifier(column.name));
		if (select) {
			const select = valuesOrSelect;
			if ((0, __entity_ts.is)(select, __sql_sql_ts.SQL)) valuesSqlList.push(select);
			else valuesSqlList.push(select.getSQL());
		} else {
			const values = valuesOrSelect;
			valuesSqlList.push(__sql_sql_ts.sql.raw("values "));
			for (const [valueIndex, value] of values.entries()) {
				const valueList = [];
				for (const [fieldName, col] of colEntries) {
					const colValue = value[fieldName];
					if (colValue === void 0 || (0, __entity_ts.is)(colValue, __sql_sql_ts.Param) && colValue.value === void 0) if (col.defaultFn !== void 0) {
						const defaultFnResult = col.defaultFn();
						const defaultValue = (0, __entity_ts.is)(defaultFnResult, __sql_sql_ts.SQL) ? defaultFnResult : __sql_sql_ts.sql.param(defaultFnResult, col);
						valueList.push(defaultValue);
					} else if (!col.default && col.onUpdateFn !== void 0) {
						const onUpdateFnResult = col.onUpdateFn();
						const newValue = (0, __entity_ts.is)(onUpdateFnResult, __sql_sql_ts.SQL) ? onUpdateFnResult : __sql_sql_ts.sql.param(onUpdateFnResult, col);
						valueList.push(newValue);
					} else valueList.push(__sql_sql_ts.sql`default`);
					else valueList.push(colValue);
				}
				valuesSqlList.push(valueList);
				if (valueIndex < values.length - 1) valuesSqlList.push(__sql_sql_ts.sql`, `);
			}
		}
		const withSql = this.buildWithCTE(withList);
		const valuesSql = __sql_sql_ts.sql.join(valuesSqlList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: true,
			ignoreCastCodecs: ignoreSelectionCastCodecs
		})}` : void 0;
		const onConflictSql = onConflict ? __sql_sql_ts.sql` on conflict ${onConflict}` : void 0;
		return __sql_sql_ts.sql`${withSql}insert into ${table} ${insertOrder} ${overridingSystemValue_ === true ? __sql_sql_ts.sql`overriding system value ` : void 0}${valuesSql}${onConflictSql}${returningSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
	}
	buildRefreshMaterializedViewQuery({ view, concurrently, withNoData }) {
		return __sql_sql_ts.sql`refresh materialized view${concurrently ? __sql_sql_ts.sql` concurrently` : void 0} ${view}${withNoData ? __sql_sql_ts.sql` with no data` : void 0}`;
	}
	sqlToQuery(sql, invokeSource) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			codecs: this.codecs,
			invokeSource
		});
	}
	_sqlToQuery(sql) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			codecs: this.codecs,
			tagged: true
		});
	}
	nestedSelectionerror() {
		throw new __errors_ts.DrizzleError({ message: `Views with nested selections are not supported by the relational query builder` });
	}
	buildRqbColumn(table, column, key, inJson) {
		if ((0, __entity_ts.is)(column, __column_ts.Column)) {
			const name = __sql_sql_ts.sql`${table}.${__sql_sql_ts.sql.identifier(column.name)}`;
			return __sql_sql_ts.sql`${inJson && column.jsonSelectIdentifier ? column.jsonSelectIdentifier(name, __sql_sql_ts.sql, column.dimensions) : this.codecs.apply(column, inJson ? "castInJson" : "cast", name)} as ${__sql_sql_ts.sql.identifier(key)}`;
		}
		return __sql_sql_ts.sql`${table}.${(0, __entity_ts.is)(column, __sql_sql_ts.SQL.Aliased) ? __sql_sql_ts.sql.identifier(column.fieldAlias) : (0, __sql_index_ts.isSQLWrapper)(column) ? __sql_sql_ts.sql.identifier(key) : this.nestedSelectionerror()} as ${__sql_sql_ts.sql.identifier(key)}`;
	}
	unwrapAllColumns = (table, selection, inJson) => {
		return __sql_sql_ts.sql.join(Object.entries(table[__table_ts.TableColumns]).map(([k, v]) => {
			selection.push((0, __entity_ts.is)(v, __column_ts.Column) ? {
				key: k,
				codec: this.codecs.get(v, inJson ? "normalizeInJson" : "normalize"),
				arrayDimensions: v.dimensions,
				field: v
			} : {
				key: k,
				field: v
			});
			return this.buildRqbColumn(table, v, k, inJson);
		}), __sql_sql_ts.sql`, `);
	};
	buildColumns = (table, selection, inJson, config) => config?.columns ? (() => {
		const entries = Object.entries(config.columns);
		const columnContainer = table[__table_ts.TableColumns];
		const columnIdentifiers = [];
		let colSelectionMode;
		for (const [k, v] of entries) {
			if (v === void 0) continue;
			colSelectionMode = colSelectionMode || v;
			if (v) {
				const column = columnContainer[k];
				columnIdentifiers.push(this.buildRqbColumn(table, column, k, inJson));
				selection.push((0, __entity_ts.is)(column, __column_ts.Column) ? {
					key: k,
					codec: this.codecs.get(column, inJson ? "normalizeInJson" : "normalize"),
					arrayDimensions: column.dimensions,
					field: column
				} : {
					key: k,
					field: column
				});
			}
		}
		if (colSelectionMode === false) for (const [k, v] of Object.entries(columnContainer)) {
			if (config.columns[k] === false) continue;
			columnIdentifiers.push(this.buildRqbColumn(table, v, k, inJson));
			selection.push((0, __entity_ts.is)(v, __column_ts.Column) ? {
				key: k,
				codec: this.codecs.get(v, inJson ? "normalizeInJson" : "normalize"),
				arrayDimensions: v.dimensions,
				field: v
			} : {
				key: k,
				field: v
			});
		}
		return columnIdentifiers.length ? __sql_sql_ts.sql.join(columnIdentifiers, __sql_sql_ts.sql`, `) : void 0;
	})() : this.unwrapAllColumns(table, selection, inJson);
	buildRelationalQuery({ schema, table, tableConfig, queryConfig: config, relationWhere, mode, errorPath, depth, throughJoin, nested }) {
		const selection = [];
		const isSingle = mode === "first";
		const params = config === true ? void 0 : config;
		const currentPath = errorPath ?? "";
		const currentDepth = depth ?? 0;
		if (!currentDepth) table = (0, __alias_ts.aliasedTable)(table, `d${currentDepth}`);
		const limit = isSingle ? 1 : params?.limit;
		const offset = params?.offset;
		const where = params?.where && relationWhere ? (0, __sql_index_ts.and)((0, __relations_ts.relationsFilterToSQL)(table, params.where, tableConfig.relations, schema), relationWhere) : params?.where ? (0, __relations_ts.relationsFilterToSQL)(table, params.where, tableConfig.relations, schema) : relationWhere;
		const order = params?.orderBy ? (0, __relations_ts.relationsOrderToSQL)(table, params.orderBy) : void 0;
		const columns = this.buildColumns(table, selection, !!nested, params);
		const extras = params?.extras ? (0, __relations_ts.relationExtrasToSQL)(table, params.extras) : void 0;
		if (extras) selection.push(...extras.selection);
		const selectionArr = columns ? [columns] : [];
		if (extras?.sql) selectionArr.push(extras.sql);
		const joins = params ? (() => {
			const { with: joins } = params;
			if (!joins) return;
			const withEntries = Object.entries(joins).filter(([_, v]) => v);
			if (!withEntries.length) return;
			return __sql_sql_ts.sql.join(withEntries.map(([k, join]) => {
				const relation = tableConfig.relations[k];
				const isSingle = (0, __entity_ts.is)(relation, __relations_ts.One);
				const targetTable = (0, __alias_ts.aliasedTable)(relation.targetTable, `d${currentDepth + 1}`);
				const throughTable = relation.throughTable ? (0, __alias_ts.aliasedTable)(relation.throughTable, `tr${currentDepth}`) : void 0;
				const { filter, joinCondition } = (0, __relations_ts.relationToSQL)(relation, table, targetTable, throughTable);
				selectionArr.push(__sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(k)}.${__sql_sql_ts.sql.identifier("r")} as ${__sql_sql_ts.sql.identifier(k)}`);
				const throughJoin = throughTable ? __sql_sql_ts.sql` inner join ${(0, __relations_ts.getTableAsAliasSQL)(throughTable)} on ${joinCondition}` : void 0;
				const innerQuery = this.buildRelationalQuery({
					table: targetTable,
					mode: isSingle ? "first" : "many",
					schema,
					queryConfig: join,
					tableConfig: schema[relation.targetTableName],
					relationWhere: filter,
					errorPath: `${currentPath.length ? `${currentPath}.` : ""}${k}`,
					depth: currentDepth + 1,
					throughJoin,
					nested: true
				});
				selection.push({
					field: targetTable,
					key: k,
					selection: innerQuery.selection,
					isArray: !isSingle,
					isOptional: (relation.optional ?? false) || join !== true && !!join.where
				});
				return __sql_sql_ts.sql`left join lateral(select ${isSingle ? __sql_sql_ts.sql`row_to_json(${__sql_sql_ts.sql.identifier("t")}.*) ${__sql_sql_ts.sql.identifier("r")}` : __sql_sql_ts.sql`coalesce(json_agg(row_to_json(${__sql_sql_ts.sql.identifier("t")}.*)), '[]') as ${__sql_sql_ts.sql.identifier("r")}`} from (${innerQuery.sql}) as ${__sql_sql_ts.sql.identifier("t")}) as ${__sql_sql_ts.sql.identifier(k)} on true`;
			}), __sql_sql_ts.sql` `);
		})() : void 0;
		if (!selectionArr.length) throw new __errors_ts.DrizzleError({ message: `No fields selected for table "${tableConfig.name}"${currentPath ? ` ("${currentPath}")` : ""}` });
		const selectionSet = __sql_sql_ts.sql.join(selectionArr.filter((e) => e !== void 0), __sql_sql_ts.sql`, `);
		const comment = config !== true && config?.comment ? __sql_sql_ts.sql.comment(config.comment) : void 0;
		return {
			sql: __sql_sql_ts.sql`select ${selectionSet} from ${(0, __relations_ts.getTableAsAliasSQL)(table)}${throughJoin}${joins ? __sql_sql_ts.sql` ${joins}` : void 0}${where ? __sql_sql_ts.sql` where ${where}` : void 0}${order ? __sql_sql_ts.sql` order by ${order}` : void 0}${limit !== void 0 ? __sql_sql_ts.sql` limit ${limit}` : void 0}${offset !== void 0 ? __sql_sql_ts.sql` offset ${offset}` : void 0}${comment ? __sql_sql_ts.sql` ${comment}` : void 0}`,
			selection
		};
	}
};

//#endregion
exports.PgDialect = PgDialect;
//# sourceMappingURL=dialect.cjs.map