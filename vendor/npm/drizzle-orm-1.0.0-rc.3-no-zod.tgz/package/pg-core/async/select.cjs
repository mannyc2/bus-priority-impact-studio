Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
const require_runtime = require('../../_virtual/_rolldown/runtime.cjs');
const require_pg_core_query_builders_select = require('../query-builders/select.cjs');
let __entity_ts = require("../../entity.cjs");
let __tracing_ts = require("../../tracing.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");

//#region src/pg-core/async/select.ts
var PgAsyncSelectBase = class extends require_pg_core_query_builders_select.PgSelectBase {
	static [__entity_ts.entityKind] = "PgAsyncSelectQueryBuilder";
	/** @internal */
	_prepare(name, generateName = false) {
		const { session, config, dialect, joinsNotNullableMap, cacheConfig, usedTables } = this;
		const { fields } = config;
		return __tracing_ts.tracer.startActiveSpan("drizzle.prepareQuery", () => {
			const query = this.config._tagged ? dialect._sqlToQuery(this.getSQL()) : dialect.sqlToQuery(this.getSQL());
			const fieldsList = (0, __utils_ts.orderSelectedFields)(fields, void 0, this.dialect.codecs);
			const mapper = this.dialect.mapperGenerators.rows(fieldsList, joinsNotNullableMap);
			return session.prepareQuery(query, "arrays", name ?? generateName, mapper, {
				type: "select",
				tables: [...usedTables]
			}, cacheConfig);
		});
	}
	/**
	* Create a prepared statement for this query. This allows
	* the database to remember this query for the given session
	* and call it by name, rather than specifying the full query.
	*
	* {@link https://www.postgresql.org/docs/current/sql-prepare.html | Postgres prepare documentation}
	*/
	prepare(name) {
		return this._prepare(name, true);
	}
	execute(placeholderValues) {
		return __tracing_ts.tracer.startActiveSpan("drizzle.operation", () => {
			return this._prepare().execute(placeholderValues);
		});
	}
};
(0, __utils_ts.applyMixins)(PgAsyncSelectBase, [__query_promise_ts.QueryPromise]);

//#endregion
exports.PgAsyncSelectBase = PgAsyncSelectBase;
//# sourceMappingURL=select.cjs.map