Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
const require_entity = require('./entity.cjs');
const require_subquery = require('./subquery.cjs');
const require_column_common = require('./column-common.cjs');
const require_column = require('./column.cjs');
const require_table = require('./table.cjs');
const require_sql_sql = require('./sql/sql.cjs');
const require_view_common = require('./view-common.cjs');

//#region src/alias.ts
var ColumnTableAliasProxyHandler = class {
	static [require_entity.entityKind] = "ColumnTableAliasProxyHandler";
	constructor(table, ignoreColumnAlias) {
		this.table = table;
		this.ignoreColumnAlias = ignoreColumnAlias;
	}
	get(columnObj, prop) {
		if (prop === "table") return this.table;
		if (prop === "isAlias" && this.ignoreColumnAlias) return false;
		return columnObj[prop];
	}
};
var ViewSelectionAliasProxyHandler = class {
	static [require_entity.entityKind] = "ViewSelectionAliasProxyHandler";
	constructor(view, selection, ignoreColumnAlias) {
		this.view = view;
		this.selection = selection;
		this.ignoreColumnAlias = ignoreColumnAlias;
	}
	get(selection, prop) {
		const value = selection[prop];
		if (require_entity.is(value, require_column.Column)) return new Proxy(value, new ColumnTableAliasProxyHandler(this.view, this.ignoreColumnAlias));
		if (require_entity.is(value, require_subquery.Subquery) || require_entity.is(value, require_sql_sql.SQL) || require_entity.is(value, require_sql_sql.SQL.Aliased) || require_sql_sql.isSQLWrapper(value) || typeof value !== "object" || value === null) return value;
		return new Proxy(value, this);
	}
};
var TableAliasProxyHandler = class {
	static [require_entity.entityKind] = "TableAliasProxyHandler";
	constructor(alias, replaceOriginalName, ignoreColumnAlias) {
		this.alias = alias;
		this.replaceOriginalName = replaceOriginalName;
		this.ignoreColumnAlias = ignoreColumnAlias;
	}
	get(target, prop) {
		if (prop === require_table.Table.Symbol.IsAlias) return true;
		if (prop === require_table.Table.Symbol.Name) return this.alias;
		if (this.replaceOriginalName && prop === require_table.Table.Symbol.OriginalName) return this.alias;
		if (prop === require_view_common.ViewBaseConfig) return {
			...target[require_view_common.ViewBaseConfig],
			name: this.alias,
			isAlias: true,
			selectedFields: new Proxy(target[require_view_common.ViewBaseConfig].selectedFields, new ViewSelectionAliasProxyHandler(new Proxy(target, this), target[require_view_common.ViewBaseConfig].selectedFields, this.ignoreColumnAlias))
		};
		if (prop === require_table.Table.Symbol.Columns) {
			const columns = target[require_table.Table.Symbol.Columns];
			if (!columns) return columns;
			if (require_entity.is(target, require_sql_sql.View)) return new Proxy(target[require_table.Table.Symbol.Columns], new ViewSelectionAliasProxyHandler(new Proxy(target, this), target[require_table.Table.Symbol.Columns], this.ignoreColumnAlias));
			const proxiedColumns = {};
			Object.keys(columns).map((key) => {
				proxiedColumns[key] = new Proxy(columns[key], new ColumnTableAliasProxyHandler(new Proxy(target, this), this.ignoreColumnAlias));
			});
			return proxiedColumns;
		}
		const value = target[prop];
		if (require_entity.is(value, require_column.Column)) return new Proxy(value, new ColumnTableAliasProxyHandler(new Proxy(target, this), this.ignoreColumnAlias));
		return value;
	}
};
var ColumnAliasProxyHandler = class {
	static [require_entity.entityKind] = "ColumnAliasProxyHandler";
	constructor(alias) {
		this.alias = alias;
	}
	get(target, prop) {
		if (prop === "isAlias") return true;
		if (prop === "name") return this.alias;
		if (prop === "keyAsName") return false;
		if (prop === require_column_common.OriginalColumn) return () => target;
		return target[prop];
	}
};
var RelationTableAliasProxyHandler = class {
	static [require_entity.entityKind] = "RelationTableAliasProxyHandler";
	constructor(alias) {
		this.alias = alias;
	}
	get(target, prop) {
		if (prop === "sourceTable") return aliasedTable(target.sourceTable, this.alias);
		return target[prop];
	}
};
function aliasedTable(table, tableAlias) {
	return new Proxy(table, new TableAliasProxyHandler(tableAlias, false, false));
}
function aliasedColumn(column, alias) {
	return new Proxy(column, new ColumnAliasProxyHandler(alias));
}
function aliasedRelation(relation, tableAlias) {
	return new Proxy(relation, new RelationTableAliasProxyHandler(tableAlias));
}
function aliasedTableColumn(column, tableAlias) {
	return new Proxy(column, new ColumnTableAliasProxyHandler(new Proxy(column.table, new TableAliasProxyHandler(tableAlias, false, false)), false));
}
function mapColumnsInAliasedSQLToAlias(query, alias) {
	return new require_sql_sql.SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
}
function mapColumnsInSQLToAlias(query, alias) {
	return require_sql_sql.sql.join(query.queryChunks.map((c) => {
		if (require_entity.is(c, require_column.Column)) return aliasedTableColumn(c, alias);
		if (require_entity.is(c, require_sql_sql.SQL)) return mapColumnsInSQLToAlias(c, alias);
		if (require_entity.is(c, require_sql_sql.SQL.Aliased)) return mapColumnsInAliasedSQLToAlias(c, alias);
		return c;
	}));
}
require_column.Column.prototype.as = function(alias) {
	return aliasedColumn(this, alias);
};
function getOriginalColumnFromAlias(column) {
	return column[require_column_common.OriginalColumn]();
}

//#endregion
exports.ColumnAliasProxyHandler = ColumnAliasProxyHandler;
exports.ColumnTableAliasProxyHandler = ColumnTableAliasProxyHandler;
exports.RelationTableAliasProxyHandler = RelationTableAliasProxyHandler;
exports.TableAliasProxyHandler = TableAliasProxyHandler;
exports.ViewSelectionAliasProxyHandler = ViewSelectionAliasProxyHandler;
exports.aliasedColumn = aliasedColumn;
exports.aliasedRelation = aliasedRelation;
exports.aliasedTable = aliasedTable;
exports.aliasedTableColumn = aliasedTableColumn;
exports.getOriginalColumnFromAlias = getOriginalColumnFromAlias;
exports.mapColumnsInAliasedSQLToAlias = mapColumnsInAliasedSQLToAlias;
exports.mapColumnsInSQLToAlias = mapColumnsInSQLToAlias;
//# sourceMappingURL=alias.cjs.map